# Termux-Eğitim

## selamın aleyküm ben Xz bu da termux eğitim setin8n kurulumu

### Kurulum için:

``apt update``

``apt upgrade``

``apt install python``

``pkg install python3``

``pkg install bash``

``git clone https://github.com/ASER-VANT/Termux-Egitim.git``

``cd Termux-Egitim``

``chmod 777 setup.sh``

``./setup.sh``
``python3 Termux-Egitim.py``
#### Kısaca asağıdaki komutu yapıştırabilirsiniz


``apt update && apt upgrade -y && apt install git -y && apt install python python2 -y && git clone storage/emulated/0/download/Termux-Egitim-main.git && cd Termux-Egitim && chmod 777 setup.sh && ./setup.sh ``

``python3 Termux-Eğitim.py``

Ulaşmak için:

instegram:muhammed_pq.10